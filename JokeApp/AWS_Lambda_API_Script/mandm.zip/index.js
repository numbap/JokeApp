var {scanLabels} = require('./scan.js')
const { RekognitionClient, DetectCustomLabelsCommand } = require("@aws-sdk/client-rekognition");     


exports.handler = async (event) => {
    // TODO implement
    var {BucketName, ImageName, AwsRegion} = event.queryStringParameters
    var labelList = await scanLabels(BucketName, ImageName, AwsRegion)
    
    const response = {
        statusCode: 200,
        //body: JSON.stringify({"Labels": labelList.CustomLabels})
        body: JSON.stringify({"Labels": labelList.CustomLabels})
    };
    
    return response;
};
