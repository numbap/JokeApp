const { RekognitionClient, DetectCustomLabelsCommand } = require("@aws-sdk/client-rekognition");     


var scanLabels = async (vBucket, vImageName, vRegion) => {


    const client = new RekognitionClient({ 
        region: vRegion, 
        projectVersionArn: "arn:aws:rekognition:us-east-1:710846612935:project/Potential/version/Potential.2022-07-28T12.06.25/1659024384659" 
        
    });
    const command = new DetectCustomLabelsCommand(
       
        {
            "ProjectVersionArn": "arn:aws:rekognition:us-east-1:710846612935:project/Potential/version/Potential.2022-07-28T12.06.25/1659024384659", 
            "Image":{ 
                "S3Object":{
                    "Bucket": vBucket,
                    "Name": vImageName
                 }
            },
            "MinConfidence": 21,
            "MaxLabels": 3,
        });
    
    try{
        const answ = await client.send(command);
        return answ 
    }catch(e){
        return e
    }    
    
}


exports.scanLabels = scanLabels;